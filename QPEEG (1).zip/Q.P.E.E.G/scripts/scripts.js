/* =========================================================
    PWA: registro del service worker
========================================================= */

if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
        navigator.serviceWorker.register("../service-worker.js").catch(() => {});
    });
}

/* =========================================================
    ESTADO
========================================================= */

const STORAGE_KEY = "qpeeg_state_v1";

const DEFAULT_STATE = {
    photo: null,
    achievements: [],
    routines: [],
    activeRoutineId: null,
    logs: {}
};

let state = loadState();

function loadState() {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (!raw) return structuredClone(DEFAULT_STATE);
        return Object.assign(structuredClone(DEFAULT_STATE), JSON.parse(raw));
    } catch (e) {
        return structuredClone(DEFAULT_STATE);
    }
}

function saveState() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function getDateText(date = new Date()) {
    const text = date.toLocaleDateString("es-ES", { weekday: "long", day: "numeric", month: "long" });
    return text.charAt(0).toUpperCase() + text.slice(1);
}

/* ---------- Registro por rutina + fecha ---------- */

let selectedDate = null; // null = hoy

function dateKey(d = new Date()) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
}

function parseKey(key) {
    const [y, m, d] = key.split("-").map(Number);
    return new Date(y, m - 1, d);
}

function getWorkoutDateKey() {
    return selectedDate || dateKey();
}

/* Lee sin crear nada */
function readExerciseLog(routineId, key, ex) {
    const stored = state.logs[routineId]?.[key]?.exercises?.[ex.id];
    return {
        kg: stored ? stored.kg : ex.kg,
        reps: ex.series.map((_, i) => (stored ? (stored.reps[i] || 0) : 0))
    };
}

/* Crea el registro si no existe (para escribir) */
function ensureExerciseLog(routineId, key, dayId, ex) {
    state.logs[routineId] ??= {};
    const entry = (state.logs[routineId][key] ??= { dayId, exercises: {} });
    entry.dayId = dayId;
    return (entry.exercises[ex.id] ??= { kg: ex.kg, reps: ex.series.map(() => 0) });
}

function exerciseStatus(ex, log) {
    const filled = log.reps.map((r, i) => ({ r, t: ex.series[i].target })).filter(x => x.r > 0);

    if (filled.length === 0) return "pending";
    if (filled.some(x => x.r < x.t)) return "red";
    if (filled.some(x => x.r > x.t)) return "gold";
    return "green";
}

function dayStatus(routine, key) {
    const entry = state.logs[routine.id]?.[key];
    if (!entry) return "empty";

    const day = findDay(routine, entry.dayId);
    if (!day || day.exercises.length === 0) return "empty";

    const statuses = day.exercises.map(ex => exerciseStatus(ex, readExerciseLog(routine.id, key, ex)));

    if (statuses.every(s => s === "pending")) return "empty";
    if (statuses.some(s => s === "pending")) return "red"; // se empezó pero no se completó
    if (statuses.includes("red")) return "red";
    if (statuses.includes("gold")) return "gold";
    return "green";
}

/* =========================================================
    PANTALLA DE INICIO
========================================================= */

let tooltipInterval = null;

function initLanding() {
    if (state.photo) {
        document.getElementById("profileImg").src = state.photo;
        document.getElementById("profileImg").style.display = "block";
        document.getElementById("profilePlaceholder").style.display = "none";
    }

    renderAchievements();
    startTooltipLoop();

    document.getElementById("profilePhoto").addEventListener("click", onProfilePhotoClick);
    document.getElementById("photoInput").addEventListener("change", onPhotoSelected);
}

function startTooltipLoop() {
    const tooltip = document.getElementById("profileTooltip");
    tooltip.classList.add("visible");
    tooltipInterval = setInterval(() => tooltip.classList.toggle("visible"), 2000);
}

function stopTooltipLoop() {
    clearInterval(tooltipInterval);
    document.getElementById("profileTooltip").classList.remove("visible");
}

function onProfilePhotoClick() {
    stopTooltipLoop();

    if (!state.photo) {
        document.getElementById("photoInput").click();
        return;
    }

    enterApp();
}

function onPhotoSelected(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
        state.photo = reader.result;
        saveState();

        document.getElementById("profileImg").src = state.photo;
        document.getElementById("profileImg").style.display = "block";
        document.getElementById("profilePlaceholder").style.display = "none";
    };
    reader.readAsDataURL(file);
}

function enterApp() {
    document.getElementById("landing").style.display = "none";
    document.getElementById("mainApp").style.display = "flex";
    setHeaderDateText(getDateText());
}

/* =========================================================
    LOGROS / OBJETIVOS (máx. 3)
========================================================= */

function renderAchievements() {
    const list = document.getElementById("achievementsList");
    const control = document.getElementById("achievementsControl");

    list.innerHTML = "";
    state.achievements.forEach(text => {
        const chip = document.createElement("div");
        chip.className = "achievement-chip";
        chip.textContent = text;
        list.appendChild(chip);
    });

    control.innerHTML = "";

    if (state.achievements.length >= 3) {
        const msg = document.createElement("p");
        msg.className = "achievements-limit";
        msg.textContent = "recuerda que no puedes ocuparte de todo, un par de cosas a la vez sin perder tu constancia";
        control.appendChild(msg);
        return;
    }

    const addBtn = document.createElement("button");
    addBtn.className = "achievements-add";
    addBtn.textContent = "+";
    addBtn.onclick = onAddAchievement;
    control.appendChild(addBtn);
}

function onAddAchievement() {
    const text = prompt("Escribe un objetivo o logro:");
    if (!text) return;

    state.achievements.push(text.trim());
    saveState();
    renderAchievements();
}

/* =========================================================
    SEMANA
========================================================= */

/* Orden cíclico de pestañas que recorren las flechas del header */
const TAB_ORDER = [
    { id: "week", label: "SEMANA" },
    { id: "exercises", label: "RUTINAS" },
    { id: "history", label: "HISTORIAL" }
];

/* Las flechitas del header recorren TAB_ORDER en bucle; desde Entreno
   (que no pertenece a TAB_ORDER) salen tomando "Semana" como base */
function shiftWeekTab(direction) {
    selectedDate = null;

    const current = document.querySelector(".section.active").id;
    let currentIndex = TAB_ORDER.findIndex(tab => tab.id === current);
    if (currentIndex === -1) currentIndex = TAB_ORDER.findIndex(tab => tab.id === "week");

    const nextIndex = (currentIndex + direction + TAB_ORDER.length) % TAB_ORDER.length;
    showSection(TAB_ORDER[nextIndex].id, { animation: "slide", direction });
}

/* =========================================================
    ANIMACIONES DE ENTRADA
    - "slide"     → cambio de pestaña (header), deslizamiento lateral
    - "transform" → entrar a una subsección, efecto de transformación
========================================================= */

function playEnterAnimation(el, type, direction) {
    if (!el || el.offsetParent === null) return;

    el.classList.remove("anim-slide-r", "anim-slide-l", "anim-transform");
    void el.offsetWidth; // fuerza reflow para poder reiniciar la animación

    if (type === "slide") {
        el.classList.add(direction < 0 ? "anim-slide-l" : "anim-slide-r");
    } else {
        el.classList.add("anim-transform");
    }
}

/* Muestra los días de la rutina activa, o el mensaje de selección */
function renderWeekSection() {
    const container = document.getElementById("weekRoutineContent");
    container.innerHTML = "";

    const routine = state.activeRoutineId ? findRoutine(state.activeRoutineId) : null;

    if (!routine) {
        state.activeRoutineId = null;
        const msg = document.createElement("p");
        msg.className = "split-caption";
        msg.textContent = "Selecciona una rutina en la pestaña Rutinas";
        container.appendChild(msg);
        return;
    }

    const picker = document.createElement("div");
    picker.className = "split-picker";

    routine.days.forEach(day => {
        const btn = document.createElement("button");
        btn.className = "split-card";
        btn.textContent = day.name;
        btn.onclick = () => startWorkoutDay(routine.id, day.id);
        picker.appendChild(btn);
    });

    container.appendChild(picker);

    const caption = document.createElement("p");
    caption.className = "split-caption";
    caption.textContent = "Elige el día de hoy";
    container.appendChild(caption);
}

/* Al elegir un día, entra a Entreno y crea/asocia el registro de esa fecha */
function startWorkoutDay(routineId, dayId) {
    activeWorkout = { routineId, dayId };
    workoutPage = 0;

    const key = getWorkoutDateKey();
    state.logs[routineId] ??= {};
    state.logs[routineId][key] ??= { dayId, exercises: {} };
    state.logs[routineId][key].dayId = dayId;
    saveState();

    showSection("workout");
}

/* Panel "Series": progreso del día activo (hechas / totales) */
function renderSeriesPanel() {
    const left = document.getElementById("seriesColLeft");
    const right = document.getElementById("seriesColRight");
    left.innerHTML = "";
    right.innerHTML = "";

    const routine = findRoutine(state.activeRoutineId);
    if (!routine) return;

    const key = getWorkoutDateKey();
    const entry = state.logs[routine.id]?.[key];
    if (!entry) return;

    const day = findDay(routine, entry.dayId);
    if (!day) return;

    const half = Math.ceil(day.exercises.length / 2);

    day.exercises.forEach((exercise, index) => {
        const log = readExerciseLog(routine.id, key, exercise);
        const done = log.reps.filter(r => r > 0).length;

        const line = document.createElement("div");
        line.className = "series-line";
        line.innerHTML = `<span>${exercise.name}</span><span>${done}/${exercise.series.length}</span>`;

        (index < half ? left : right).appendChild(line);
    });
}

/* =========================================================
    NAVEGACIÓN ENTRE SECCIONES
========================================================= */

function showSection(sectionId, opts = {}) {
    document.querySelectorAll(".section").forEach(s => s.classList.remove("active"));
    const sectionEl = document.getElementById(sectionId);
    sectionEl.classList.add("active");
    playEnterAnimation(sectionEl, opts.animation || "transform", opts.direction);

    const label = document.querySelector(".week-tab-label");
    label.onclick = null;
    label.classList.remove("clickable");

    if (sectionId === "exercises") {
        routineNav = { level: "root", routineId: null, dayId: null, exercisePage: 0 };
        renderRoutinesTab();
    } else if (sectionId === "week") {
        setHeaderDateText(getDateText(selectedDate ? parseKey(selectedDate) : new Date()));
        renderWeekSection();
        renderSeriesPanel();
    } else if (sectionId === "workout") {
        const day = findDay(findRoutine(activeWorkout.routineId), activeWorkout.dayId);
        setHeaderDateText(day ? day.name : "");
        renderWorkoutForDay(activeWorkout.routineId, activeWorkout.dayId);
    } else if (sectionId === "history") {
        setHeaderDateText(getDateText());
        renderHistory();
    } else {
        setHeaderDateText("");
    }

    const tab = TAB_ORDER.find(t => t.id === sectionId);
    label.textContent = tab ? tab.label : (sectionId === "workout" ? "ENTRENO" : label.textContent);
}

function goToWeek() {
    selectedDate = null;
    showSection("week");
}

/* =========================================================
    ENTRENAMIENTO: CARRUSELES DE KG Y REPS
========================================================= */

const KG_STEP = 2.5;
const EXERCISES_PER_SCREEN = 2;

let workoutPage = 0;
let activeWorkout = { routineId: null, dayId: null };

function renderWorkoutForDay(routineId, dayId) {
    const container = document.getElementById("workoutExercises");
    container.innerHTML = "";

    const routine = findRoutine(routineId);
    const day = routine ? findDay(routine, dayId) : null;
    if (!day) return;

    const totalPages = Math.max(1, Math.ceil(day.exercises.length / EXERCISES_PER_SCREEN));
    workoutPage = Math.min(workoutPage, totalPages - 1);

    const start = workoutPage * EXERCISES_PER_SCREEN;

    const page = document.createElement("div");
    page.className = "workout-page";

    day.exercises.slice(start, start + EXERCISES_PER_SCREEN)
        .forEach(exercise => page.appendChild(buildExerciseCard(routineId, dayId, exercise.id)));

    container.appendChild(page);

    document.getElementById("workoutUp").style.visibility = workoutPage > 0 ? "visible" : "hidden";
    document.getElementById("workoutDown").style.visibility = workoutPage < totalPages - 1 ? "visible" : "hidden";
}

function shiftWorkoutPage(direction) {
    workoutPage += direction;
    renderWorkoutForDay(activeWorkout.routineId, activeWorkout.dayId);
}

function getWorkoutExercise(routineId, dayId, exerciseId) {
    const day = findDay(findRoutine(routineId), dayId);
    return day.exercises.find(e => e.id === exerciseId);
}

function buildExerciseCard(routineId, dayId, exerciseId) {
    const ex = getWorkoutExercise(routineId, dayId, exerciseId);
    const log = readExerciseLog(routineId, getWorkoutDateKey(), ex);

    const card = document.createElement("div");
    card.className = "exercise";
    card.dataset.exercise = exerciseId;

    const top = document.createElement("div");
    top.className = "exercise-top";
    top.innerHTML = `
        <div class="exercise-name">${ex.name}</div>
        <span class="semaphore-dot" id="dot-${exerciseId}"></span>
    `;
    card.appendChild(top);

    const kgBox = document.createElement("div");
    kgBox.className = "kg-carousel";
    kgBox.innerHTML = `
        <button class="carousel-arrow" data-action="kg-up">▲</button>
        <div class="kg-value" id="kg-${exerciseId}">${log.kg} kg</div>
        <button class="carousel-arrow" data-action="kg-down">▼</button>
    `;
    kgBox.querySelector('[data-action="kg-up"]').onclick = () => changeWorkoutKg(routineId, dayId, exerciseId, KG_STEP);
    kgBox.querySelector('[data-action="kg-down"]').onclick = () => changeWorkoutKg(routineId, dayId, exerciseId, -KG_STEP);
    card.appendChild(kgBox);

    const seriesRow = document.createElement("div");
    seriesRow.className = "series-row";
    seriesRow.id = `series-row-${exerciseId}`;
    card.appendChild(seriesRow);

    renderWorkoutSeries(routineId, dayId, exerciseId, card);

    return card;
}

function renderWorkoutSeries(routineId, dayId, exerciseId, cardEl) {
    const ex = getWorkoutExercise(routineId, dayId, exerciseId);
    const log = readExerciseLog(routineId, getWorkoutDateKey(), ex);
    const row = (cardEl || document.querySelector(`.exercise[data-exercise="${exerciseId}"]`))
        .querySelector(`#series-row-${exerciseId}`);

    row.innerHTML = "";

    ex.series.forEach((serie, index) => {
        const wrap = document.createElement("div");
        wrap.className = "serie-carousel";
        wrap.innerHTML = `
            <span class="serie-label">${toRoman(index + 1)}</span>
            <button class="carousel-arrow small">▲</button>
            <div class="reps-value">${log.reps[index]}</div>
            <button class="carousel-arrow small">▼</button>
        `;
        wrap.querySelectorAll(".carousel-arrow")[0].onclick = () => changeWorkoutReps(routineId, dayId, exerciseId, index, 1);
        wrap.querySelectorAll(".carousel-arrow")[1].onclick = () => changeWorkoutReps(routineId, dayId, exerciseId, index, -1);
        row.appendChild(wrap);
    });

    updateSemaphore(routineId, dayId, exerciseId);
}

function changeWorkoutKg(routineId, dayId, exerciseId, delta) {
    const ex = getWorkoutExercise(routineId, dayId, exerciseId);
    const log = ensureExerciseLog(routineId, getWorkoutDateKey(), dayId, ex);
    log.kg = Math.max(0, log.kg + delta);
    saveState();
    document.getElementById(`kg-${exerciseId}`).textContent = `${log.kg} kg`;
}

function changeWorkoutReps(routineId, dayId, exerciseId, index, delta) {
    const ex = getWorkoutExercise(routineId, dayId, exerciseId);
    const log = ensureExerciseLog(routineId, getWorkoutDateKey(), dayId, ex);
    log.reps[index] = Math.max(0, (log.reps[index] || 0) + delta);
    saveState();
    renderWorkoutSeries(routineId, dayId, exerciseId);
    renderSeriesPanel();
}

function toRoman(number) {
    const romans = ["I", "II", "III", "IV", "V", "VI"];
    return romans[number - 1] || number;
}

/* =========================================================
    SEMÁFORO (verde / dorado / rojo)
========================================================= */

function updateSemaphore(routineId, dayId, exerciseId) {
    const ex = getWorkoutExercise(routineId, dayId, exerciseId);
    const dot = document.getElementById(`dot-${exerciseId}`);
    if (!dot) return;

    const status = exerciseStatus(ex, readExerciseLog(routineId, getWorkoutDateKey(), ex));

    dot.classList.remove("dot-green", "dot-yellow", "dot-red");
    if (status === "red") dot.classList.add("dot-red");
    else if (status === "gold") dot.classList.add("dot-yellow");
    else if (status === "green") dot.classList.add("dot-green");
    // "pending": punto gris por defecto
}

/* =========================================================
    CREADOR DE RUTINAS (pestaña "Rutinas")
========================================================= */

const EXERCISE_NAME_MAX = 14;

let routineNav = { level: "root", routineId: null, dayId: null, exercisePage: 0 };

function newId(prefix) {
    return `${prefix}_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
}

function findRoutine(routineId) {
    return state.routines.find(r => r.id === routineId);
}

function findDay(routine, dayId) {
    return routine.days.find(d => d.id === dayId);
}

function setHeaderDateText(text, onBack) {
    const el = document.getElementById("weekDate");

    if (onBack) {
        el.textContent = `← ${text}`;
        el.classList.add("clickable");
        el.onclick = onBack;
    } else {
        el.textContent = text;
        el.classList.remove("clickable");
        el.onclick = null;
    }
}

function renderRoutinesTab() {
    const container = document.getElementById("routinesContainer");
    container.innerHTML = "";

    if (routineNav.level === "root") {
        setHeaderDateText(getDateText());
        container.appendChild(buildRoutinesRoot());
    } else if (routineNav.level === "days") {
        setHeaderDateText(findRoutine(routineNav.routineId).name, () => {
            routineNav = { level: "root", routineId: null, dayId: null };
            renderRoutinesTab();
        });
        container.appendChild(buildDaysView(routineNav.routineId));
    } else if (routineNav.level === "exercises") {
        const day = findDay(findRoutine(routineNav.routineId), routineNav.dayId);
        setHeaderDateText(day.name, () => {
            routineNav = { level: "days", routineId: routineNav.routineId, dayId: null };
            renderRoutinesTab();
        });
        container.appendChild(buildDayExercisesView(routineNav.routineId, routineNav.dayId));
    }

    playEnterAnimation(container, "transform");
}

/* ---------- Nivel 1: lista de rutinas ---------- */

function buildRoutinesRoot() {
    const root = document.createElement("div");
    root.className = "routine-page";

    const gridWrapper = document.createElement("div");
    gridWrapper.className = "day-grid-wrapper";

    const grid = document.createElement("div");
    grid.className = "day-grid";
    const isTwoColumns = state.routines.length >= 4;
    grid.classList.toggle("two-columns", isTwoColumns);

    state.routines.forEach(routine => {
        const card = document.createElement("button");
        card.className = "day-card routine-pill";
        card.classList.toggle("routine-active", state.activeRoutineId === routine.id);

        const activateBtn = document.createElement("button");
        activateBtn.className = "routine-activate";
        activateBtn.textContent = state.activeRoutineId === routine.id ? "Activado" : "Activar";
        activateBtn.onclick = (event) => {
            event.stopPropagation();
            toggleActiveRoutine(routine.id);
        };
        card.appendChild(activateBtn);

        const xBtn = document.createElement("span");
        xBtn.className = "day-delete-x";
        xBtn.textContent = "✕";
        xBtn.onclick = (event) => {
            event.stopPropagation();
            deleteRoutine(routine.id);
        };
        card.appendChild(xBtn);

        const label = document.createElement("span");
        label.textContent = routine.name;
        card.appendChild(label);

        card.onclick = () => {
            routineNav = { level: "days", routineId: routine.id, dayId: null };
            renderRoutinesTab();
        };
        grid.appendChild(card);
    });

    const addCard = document.createElement("button");
    addCard.className = "square-card add-square";

    if ((state.routines.length + 1) % 2 === 1 && isTwoColumns) {
        addCard.classList.add("add-day-full-row");
    }

    addCard.innerHTML = `<span class="add-square-plus">+</span><small>Añadir rutina</small>`;
    addCard.onclick = addRoutine;
    grid.appendChild(addCard);

    if (state.routines.length === 0) {
        gridWrapper.classList.add("empty-wrapper");
        grid.classList.add("empty-grid");
    }

    gridWrapper.appendChild(grid);
    root.appendChild(gridWrapper);

    return root;
}

function deleteRoutine(routineId) {
    const routine = findRoutine(routineId);

    if (!confirm(`¿Borrar la rutina "${routine.name}" completa, con todos sus días y ejercicios? Esta acción no se puede deshacer.`)) return;

    state.routines = state.routines.filter(r => r.id !== routineId);
    saveState();

    routineNav = { level: "root", routineId: null, dayId: null };
    renderRoutinesTab();
}

function toggleActiveRoutine(routineId) {
    state.activeRoutineId = (state.activeRoutineId === routineId) ? null : routineId;
    saveState();
    renderRoutinesTab();
}

function addRoutine() {
    const name = prompt("Nombre de la rutina:");
    if (!name) return;

    const routine = { id: newId("routine"), name: name.trim(), days: [] };
    state.routines.push(routine);
    saveState();

    routineNav = { level: "days", routineId: routine.id, dayId: null };
    renderRoutinesTab();
}

/* ---------- Nivel 2: días de una rutina ---------- */

function buildDaysView(routineId) {
    const routine = findRoutine(routineId);

    const root = document.createElement("div");
    root.className = "routine-page";

    const gridWrapper = document.createElement("div");
    gridWrapper.className = "day-grid-wrapper";

    const grid = document.createElement("div");
    grid.className = "day-grid";
    const isTwoColumns = routine.days.length >= 4;
    grid.classList.toggle("two-columns", isTwoColumns);

    routine.days.forEach(day => {
        const card = document.createElement("button");
        card.className = "day-card";

        const xBtn = document.createElement("span");
        xBtn.className = "day-delete-x";
        xBtn.textContent = "✕";
        xBtn.onclick = (event) => {
            event.stopPropagation();
            deleteDay(routineId, day.id);
        };
        card.appendChild(xBtn);

        const label = document.createElement("span");
        label.textContent = day.name;
        card.appendChild(label);

        card.onclick = () => {
            routineNav = { level: "exercises", routineId, dayId: day.id };
            renderRoutinesTab();
        };
        attachLongPress(card, () => renameDay(routineId, day.id));
        grid.appendChild(card);
    });

    if (routine.days.length < 6) {
        const addCard = document.createElement("button");
        addCard.className = "square-card add-square";

        if ((routine.days.length + 1) % 2 === 1 && isTwoColumns) {
            addCard.classList.add("add-day-full-row");
        }

        addCard.innerHTML = `<span class="add-square-plus">+</span><small>Añadir día</small>`;
        addCard.onclick = () => addDay(routineId);
        grid.appendChild(addCard);
    }

    if (routine.days.length === 0) {
        gridWrapper.classList.add("empty-wrapper");
        grid.classList.add("empty-grid");
    }

    gridWrapper.appendChild(grid);
    root.appendChild(gridWrapper);

    const hint = document.createElement("p");
    hint.className = "hint-text";
    hint.textContent = "Toca un día para abrirlo. Mantén presionado para renombrarlo. Máx. 6 días.";
    root.appendChild(hint);

    return root;
}

function renumberAutoDays(routine) {
    routine.days.forEach((day, index) => {
        if (!day.customName) day.name = `Día ${index + 1}`;
    });
}

function addDay(routineId) {
    const routine = findRoutine(routineId);
    if (routine.days.length >= 6) return;

    routine.days.push({ id: newId("day"), name: "", customName: false, exercises: [] });
    renumberAutoDays(routine);
    saveState();
    renderRoutinesTab();
}

function deleteDay(routineId, dayId) {
    const routine = findRoutine(routineId);
    const day = findDay(routine, dayId);

    if (!confirm(`¿Borrar "${day.name}" y todos sus ejercicios? Esta acción no se puede deshacer.`)) return;

    routine.days = routine.days.filter(d => d.id !== dayId);
    renumberAutoDays(routine);
    saveState();
    renderRoutinesTab();
}

function renameDay(routineId, dayId) {
    const routine = findRoutine(routineId);
    const day = findDay(routine, dayId);

    const name = prompt("Nombre del día:", day.name);
    if (!name) return;

    day.name = name.trim();
    day.customName = true;
    saveState();
    renderRoutinesTab();
}

/* ---------- Nivel 3: ejercicios dentro de un día (paginado, 2 por página, máx. 6 páginas) ---------- */

const EXERCISES_PER_PAGE = 2;
const MAX_EXERCISE_PAGES = 6;

function buildDayExercisesView(routineId, dayId) {
    const routine = findRoutine(routineId);
    const day = findDay(routine, dayId);

    const root = document.createElement("div");
    root.className = "routine-page";

    const page = routineNav.exercisePage || 0;
    const startIndex = page * EXERCISES_PER_PAGE;
    const pageExercises = day.exercises.slice(startIndex, startIndex + EXERCISES_PER_PAGE);

    const list = document.createElement("div");
    list.className = "day-exercises-list";

    pageExercises.forEach((exercise, localIndex) => {
        list.appendChild(buildRoutineExerciseCard(routineId, dayId, startIndex + localIndex));
    });

    root.appendChild(list);

    const totalPages = Math.max(1, Math.ceil(day.exercises.length / EXERCISES_PER_PAGE));

    const pageIndicator = document.createElement("div");
    pageIndicator.className = "page-indicator";
    for (let i = 0; i < totalPages; i++) {
        const dot = document.createElement("span");
        dot.className = "page-dot" + (i === page ? " active" : "");
        pageIndicator.appendChild(dot);
    }
    root.appendChild(pageIndicator);

    /* Botones inferiores: ← [+] →, centrados. Volver solo si hay página
       anterior; avanzar solo si ya existe una página siguiente. */
    const actions = document.createElement("div");
    actions.className = "routine-actions";

    if (page > 0) {
        const backBtn = document.createElement("button");
        backBtn.className = "add-serie-btn";
        backBtn.textContent = "←";
        backBtn.onclick = () => { routineNav.exercisePage--; renderRoutinesTab(); };
        actions.appendChild(backBtn);
    }

    if (totalPages < MAX_EXERCISE_PAGES) {
        const addBtn = document.createElement("button");
        addBtn.className = "add-serie-btn";
        addBtn.textContent = "+";
        addBtn.onclick = () => addRoutineExercise(routineId, dayId);
        actions.appendChild(addBtn);
    }

    if (page < totalPages - 1) {
        const forwardBtn = document.createElement("button");
        forwardBtn.className = "add-serie-btn";
        forwardBtn.textContent = "→";
        forwardBtn.onclick = () => { routineNav.exercisePage++; renderRoutinesTab(); };
        actions.appendChild(forwardBtn);
    }

    root.appendChild(actions);

    const help = document.createElement("p");
    help.className = "routine-help";
    help.textContent = "Máx. 6 series por ejercicio y máx. 6 páginas de ejercicios (2 por página). Mantén presionado el peso para introducirlo manualmente. Mantén presionada una serie para eliminarla.";
    root.appendChild(help);

    return root;
}

function addRoutineExercise(routineId, dayId) {
    const routine = findRoutine(routineId);
    const day = findDay(routine, dayId);

    const currentPages = Math.ceil(day.exercises.length / EXERCISES_PER_PAGE);
    if (day.exercises.length % EXERCISES_PER_PAGE === 0 && currentPages >= MAX_EXERCISE_PAGES) {
        alert(`Máximo ${MAX_EXERCISE_PAGES} páginas de ejercicios por día.`);
        return;
    }

    let name = prompt(`Nombre del ejercicio (máx. ${EXERCISE_NAME_MAX} caracteres):`);
    if (!name) return;
    name = name.trim().slice(0, EXERCISE_NAME_MAX);
    if (!name) return;

    day.exercises.push({
        id: newId("ex"),
        name,
        kg: 0,
        series: [{ target: 0, actual: 0 }, { target: 0, actual: 0 }, { target: 0, actual: 0 }]
    });

    saveState();

    routineNav.exercisePage = Math.floor((day.exercises.length - 1) / EXERCISES_PER_PAGE);
    renderRoutinesTab();
}

function deleteRoutineExercise(routineId, dayId, exerciseIndex) {
    const routine = findRoutine(routineId);
    const day = findDay(routine, dayId);
    const exercise = day.exercises[exerciseIndex];

    if (!confirm(`¿Borrar el ejercicio "${exercise.name}"? Esta acción no se puede deshacer.`)) return;

    day.exercises.splice(exerciseIndex, 1);
    saveState();

    const totalPages = Math.max(1, Math.ceil(day.exercises.length / EXERCISES_PER_PAGE));
    if (routineNav.exercisePage >= totalPages) routineNav.exercisePage = totalPages - 1;

    renderRoutinesTab();
}

const MAX_SERIES_PER_EXERCISE = 6;

function buildRoutineExerciseCard(routineId, dayId, exerciseIndex) {
    const routine = findRoutine(routineId);
    const day = findDay(routine, dayId);
    const exercise = day.exercises[exerciseIndex];

    const card = document.createElement("div");
    card.className = "exercise";
    card.style.position = "relative"; // necesario para posicionar la X

    const deleteBtn = document.createElement("span");
    deleteBtn.className = "day-delete-x";
    deleteBtn.textContent = "✕";
    deleteBtn.onclick = (event) => {
        event.stopPropagation();
        deleteRoutineExercise(routineId, dayId, exerciseIndex);
    };
    card.appendChild(deleteBtn);

    const name = document.createElement("div");
    name.className = "exercise-name";
    name.textContent = exercise.name;
    card.appendChild(name);

    const kgBox = document.createElement("div");
    kgBox.className = "kg-carousel";
    kgBox.innerHTML = `
        <button class="carousel-arrow">▲</button>
        <div class="kg-value long-pressable">${exercise.kg} kg/lbs</div>
        <button class="carousel-arrow">▼</button>
    `;
    kgBox.querySelectorAll(".carousel-arrow")[0].onclick = () => changeRoutineKg(routineId, dayId, exerciseIndex, KG_STEP);
    kgBox.querySelectorAll(".carousel-arrow")[1].onclick = () => changeRoutineKg(routineId, dayId, exerciseIndex, -KG_STEP);
    attachLongPress(kgBox.querySelector(".kg-value"), () => setCustomRoutineKg(routineId, dayId, exerciseIndex));
    card.appendChild(kgBox);

    const seriesRow = document.createElement("div");
    seriesRow.className = "series-row";

    exercise.series.forEach((serie, serieIndex) => {
        const el = document.createElement("div");
        el.className = "serie-carousel long-pressable";
        el.innerHTML = `
            <span class="serie-label">${toRoman(serieIndex + 1)}</span>
            <button class="carousel-arrow small">▲</button>
            <div class="reps-value">${serie.target}</div>
            <button class="carousel-arrow small">▼</button>
        `;
        el.querySelectorAll(".carousel-arrow")[0].onclick = () => changeRoutineReps(routineId, dayId, exerciseIndex, serieIndex, 1);
        el.querySelectorAll(".carousel-arrow")[1].onclick = () => changeRoutineReps(routineId, dayId, exerciseIndex, serieIndex, -1);
        attachLongPress(el.querySelector(".reps-value"), () => removeRoutineSerie(routineId, dayId, exerciseIndex, serieIndex));
        seriesRow.appendChild(el);
    });

    card.appendChild(seriesRow);

    if (exercise.series.length < MAX_SERIES_PER_EXERCISE) {
        const addSerieBtn = document.createElement("button");
        addSerieBtn.className = "add-serie-btn";
        addSerieBtn.textContent = "+";
        addSerieBtn.onclick = () => {
            exercise.series.push({ target: 0, actual: 0 });
            saveState();
            renderRoutinesTab();
        };
        card.appendChild(addSerieBtn);
    }

    return card;
}

function changeRoutineKg(routineId, dayId, exerciseIndex, delta) {
    const day = findDay(findRoutine(routineId), dayId);
    const exercise = day.exercises[exerciseIndex];

    exercise.kg = Math.max(0, exercise.kg + delta);
    saveState();
    renderRoutinesTab();
}

function changeRoutineReps(routineId, dayId, exerciseIndex, serieIndex, delta) {
    const day = findDay(findRoutine(routineId), dayId);
    const serie = day.exercises[exerciseIndex].series[serieIndex];

    serie.target = Math.max(0, serie.target + delta);
    saveState();
    renderRoutinesTab();
}

function setCustomRoutineKg(routineId, dayId, exerciseIndex) {
    const day = findDay(findRoutine(routineId), dayId);
    const exercise = day.exercises[exerciseIndex];

    const value = prompt("Introduce el peso personalizado (kg/lbs):", exercise.kg);
    if (value === null) return;

    const number = parseFloat(value.replace(",", "."));
    if (isNaN(number) || number < 0) {
        alert("Introduce un peso válido.");
        return;
    }

    exercise.kg = number;
    saveState();
    renderRoutinesTab();
}

function removeRoutineSerie(routineId, dayId, exerciseIndex, serieIndex) {
    const day = findDay(findRoutine(routineId), dayId);
    const exercise = day.exercises[exerciseIndex];

    if (exercise.series.length <= 1) return;

    exercise.series.splice(serieIndex, 1);
    saveState();
    renderRoutinesTab();
}

/* ---------- Piezas reutilizables del creador de rutinas ---------- */

function attachLongPress(el, callback) {
    let timer = null;

    const start = (event) => {
        if (event.type === "mousedown" && event.button !== 0) return;
        timer = setTimeout(callback, 550);
    };

    const cancel = () => {
        if (timer) {
            clearTimeout(timer);
            timer = null;
        }
    };

    el.addEventListener("mousedown", start);
    el.addEventListener("touchstart", start, { passive: true });
    el.addEventListener("mouseup", cancel);
    el.addEventListener("mouseleave", cancel);
    el.addEventListener("touchend", cancel);
    el.addEventListener("touchcancel", cancel);
    el.addEventListener("touchmove", cancel);
}

/* =========================================================
    HISTORIAL
========================================================= */

function renderHistory() {
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth();

    const title = now.toLocaleDateString("es-ES", { month: "long", year: "numeric" });
    document.getElementById("historyTitle").textContent = title.charAt(0).toUpperCase() + title.slice(1);

    const grid = document.getElementById("historyGrid");
    grid.innerHTML = "";

    const routine = findRoutine(state.activeRoutineId);
    if (!routine) {
        const msg = document.createElement("p");
        msg.className = "split-caption";
        msg.style.gridColumn = "1 / -1";
        msg.textContent = "Selecciona una rutina en la pestaña Rutinas";
        grid.appendChild(msg);
        return;
    }

    ["L", "M", "X", "J", "V", "S", "D"].forEach(letter => {
        const h = document.createElement("div");
        h.className = "history-weekday";
        h.textContent = letter;
        grid.appendChild(h);
    });

    const firstOffset = (new Date(year, month, 1).getDay() + 6) % 7; // lunes primero
    for (let i = 0; i < firstOffset; i++) {
        const blank = document.createElement("div");
        blank.className = "history-cell blank";
        grid.appendChild(blank);
    }

    const todayKey = dateKey(now);
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    for (let d = 1; d <= daysInMonth; d++) {
        const key = dateKey(new Date(year, month, d));
        const status = dayStatus(routine, key);

        const cell = document.createElement("button");
        cell.className = "history-cell";
        cell.textContent = d;

        if (status === "green") cell.classList.add("green");
        if (status === "red") cell.classList.add("red");
        if (status === "gold") cell.classList.add("gold");
        if (key === todayKey) cell.classList.add("today");

        if (key > todayKey) {
            cell.classList.add("future");
        } else {
            cell.onclick = () => openHistoryDay(key);
        }

        grid.appendChild(cell);
    }
}

/* Tocar un día: abre su entreno si ya existe, o el selector de días de la rutina */
function openHistoryDay(key) {
    selectedDate = (key === dateKey()) ? null : key;

    const entry = state.logs[state.activeRoutineId]?.[key];
    const routine = findRoutine(state.activeRoutineId);

    if (entry && routine && findDay(routine, entry.dayId)) {
        activeWorkout = { routineId: routine.id, dayId: entry.dayId };
        workoutPage = 0;
        showSection("workout");
    } else {
        showSection("week");
    }
}

function completeWorkout() {
    goToWeek();
}

/* =========================================================
    ARRANQUE
========================================================= */

document.addEventListener("DOMContentLoaded", () => {
    initLanding();
    renderWeekSection();
    renderSeriesPanel();
    renderRoutinesTab();
});
